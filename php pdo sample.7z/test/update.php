<?php 
    require_once('Students.php');

    $ID = $_GET['id'];    
    $student = Student::find_by_id($ID); 

    if(isset($_POST['btn_update']))
    {
        $student = new Student();
        $student->ID = $_GET['id'];
        $student->firstname= $_POST['firstname'];
        $student->lastname = $_POST['lastname'];
        
        try {
        	$student->save();
        	$msg = "Record successfully updated!";        	
        	header('Refresh: 2;url=index.php');
    	} catch (Exception $e) {
    		$msg = 'Caught exception: ' .  $e->getMessage() . "\n";
    	}
    }
?>  
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Update Record</title>
</head>
<body>
<div class="updatestudent">
    <h2>Update Record</h2>

    <form action="<?php $_SERVER['PHP_SELF']; ?>" method="post">
        <p>
            <label for="firstname">Firstname:</label>
            <input type="text" name="firstname" id="firstname" value="<?php echo $student->firstname ?>">
        </p>
        <p>
            <label for="lastname">Lastname:</label>
            <input type="text" name="lastname" id="lastname" value="<?php echo $student->lastname ?>">
        </p>
        <input type="submit" name="btn_update" value="Update" />
    </form>

    <?php if(isset($msg)): ?>
        <div id="status"><p><?php echo $msg; ?></p></div>
	<?php endif; ?>
</div>	
</body>
</html>