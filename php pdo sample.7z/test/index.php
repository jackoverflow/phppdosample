<?php 
    require_once('Students.php');

    $sql = "SELECT * FROM students";
    $students = Student::find_by_sql($sql);    
?>   
<?php
    $student = new Student();

    if (isset($_POST['submit'])){
        $student = new Student();
        $student->firstname = $_POST['firstname'];
        $student->lastname = $_POST['lastname'];

        try {
            $student->save();
            $msg = "Record successfully added!";
        } catch (Exception $e) {
            $msg = 'Caught exception: ' .  $e->getMessage() . "\n";
        }

    }
?> 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>PDO Test</title>
    <script src="bower_components/jquery/dist/jquery.js"></script>
    <link rel="stylesheet" href="css/main.css">
</head>
<body>
<div class="allstudents">
    <h2>Students</h2>
    <table>
        <tr class="headings">
            <th>ID</th>
            <th>Firstname</th>
            <th>Lastname</th>
            <th>Update</th>
            <th>Delete</th>
        </tr>
        <tr>
        <?php
            $students = Student::find_by_sql($sql);
            foreach($students as $student) {
        ?>
            <tr>
                <td><?php echo $student->ID ?></td>
                <td><?php echo $student->firstname ?></td>
                <td><?php echo $student->lastname ?></td>
                <td class="links"><a href="update.php?id=<?php echo $student->ID ?>">Update</a></td>
                <td class="links">
                    <a href="delete.php?id=<?php echo $student->ID ?>" onclick="return confirmation()">Delete</a>
                </td>
            </tr>
        <?php
            }
        ?>
        </tr>
    </table>
</div>

<div class="addstudent">
    <h2>Add Student</h2>

    <form action="<?php $_SERVER['PHP_SELF']; ?>" method="post">
        <p>
            <label for="firstname">Firstname:</label>
            <input type="text" name="firstname" id="firstname">
        </p>
        <p>
            <label for="lastname">Lastname:</label>
            <input type="text" name="lastname" id="lastname">
        </p>
        <input type="submit" name="submit" value="Submit" />
    </form>
    <?php if(isset($msg)): ?>
        <div id="status"><p><?php echo $msg; ?></p></div>
    <?php endif; ?>    
</div>

<script type="text/javascript">
    function confirmation() {
      return confirm('Are you sure you want to delete this record?');
    }
</script>

</body>
</html>
