<?php
    require_once('Students.php');

    $ID = $_GET['id'];
    $stud = new Student();
    $stud->ID = $ID;
    $stud->delete(); 
    
    header("location: index.php");