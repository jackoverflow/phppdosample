<?php
include 'connection.php';

class Student {
    public $ID;
    public $firstname;
    public $lastname;  

    public static function find_all() 
    {
        return self::find_by_sql("SELECT * FROM students");
    }

    public static function find_by_sql($sql = "")
    {       
        global $dbh;
                
        $query = $dbh->query($sql);
        $object_array = array();
        while($r = $query->fetch(PDO::FETCH_OBJ)) {
            $object_array[] = $r;
        }       
        return $object_array;
    }

    public static function find_by_id($id=0)
    {

        $result_array = self::find_by_sql("SELECT * FROM students WHERE id={$id} LIMIT 1");
        return !empty($result_array) ? array_shift($result_array) : false;

    }    

    public function create() 
    {
        global $dbh;

        $sql  = "INSERT INTO students (";
        $sql .= "firstname, lastname";
        $sql .= ") VALUES (:firstname, :lastname)" ;
        
        $statement = $dbh->prepare($sql);
        $statement->execute(array(
            "firstname"=> $this->firstname,
            "lastname"=> $this->lastname
        ));
    }

    public function update()
    {
        global $dbh;

        $sql     = "UPDATE students ";
        $sql    .= "SET firstname =  '{$this->firstname}'  , lastname =  '{$this->lastname}' ";
        $sql    .= "WHERE ID = {$this->ID} ";
        
        $statement = $dbh->prepare($sql);
        $statement->execute();
    }

    public function save() 
    {
        return isset($this->ID) ? $this->update() : $this->create();
    }

    public function delete()
    {
        global $dbh;

        $sql  = "DELETE FROM students WHERE ID = {$this->ID} LIMIT 1";

        $statement = $dbh->prepare($sql);
        $statement->execute();
    }    
}